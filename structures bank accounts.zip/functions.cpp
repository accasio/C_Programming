#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include "accounts.h"
#include "math.h"


// sets up the array of accounts with random balances and account numbers
void setupAccounts(struct account accounts[], int num);

// uses calcInterest and calcTax to calculate the interest and tax, and update the account balances
void updateAccounts(struct account accounts[], int num);

// calculates the interest on the balance, using the interest rate defined in accounts.h
double calcInterest(double balance);

// calculates the tax on the interest, using the tax rate defined in accounts.h
double calcTax(double interest);

// uses printAccount to print out an array of accounts
void printAccounts(struct account accounts[], int num);

// prints an individual account
void printAccount(struct account anAccount);

void setupAccounts(struct account accounts[], int num)
{
	int i;

	for (i = 0; i < 10; i++)
	{
		accounts[i].num = rand() % 100;
		accounts[i].balance = rand() % 1000;
		accounts[i].interest = 0;
		accounts[i].tax = 0;
	}
}

void printAccounts(struct account accounts[], int num)
{
	int i;
	account anAccount = { 0.0, 0.0, 0.0, 0.0};

	printf("\nAccount\tBalance\tInterest Tax\n");
	printf("------\t------\t------\t------\n");

	for (i = 0; i < 10; i++)
	{
		anAccount.balance = accounts[i].balance;
		anAccount.interest = accounts[i].interest;
		anAccount.num = accounts[i].num;
		anAccount.tax = accounts[i].tax;
		printAccount(account(anAccount));
	}
	/*for (i = 0; i < 10; i++)
	{
		printf("%d\t%.2lf\t%.2lf\t%.2lf\n", accounts[i].num, accounts[i].balance, accounts[i].interest, accounts[i].tax);
	}*/
}

void updateAccounts(struct account accounts[], int num)
{
	int i;
	double balance;
	double interest;
	double tax;
	
	for (i = 0; i < 10; i++) 
	{
		balance = accounts[i].balance;
		accounts[i].interest = calcInterest(balance);
		interest = accounts[i].interest;
		accounts[i].tax = calcTax(interest);
		accounts[i].balance = accounts[i].balance + accounts[i].interest - accounts[i].tax;

	}
}

double calcInterest(double balance)
{
	double interest;

	interest = balance * interestRate;
	return interest;	
}

double calcTax(double interest)
{
	double tax;

	tax = interest * taxRate;
	return tax;
}

void printAccount(struct account anAccount)
{
	printf("%d\t%.2lf\t%.2lf\t%.2lf\n", anAccount.num, anAccount.balance, anAccount.interest, anAccount.tax);
}